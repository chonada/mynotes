"""
================================================================================
Agentic RAG — CLI entry point
================================================================================

A research agent that combines:
    • RAG over an indexed corpus of research-paper PDFs (PyMuPDF + Chroma +
      OpenAI embeddings)
    • Live financial market data (yfinance — no API key required)
    • Tool-calling orchestration (OpenAI gpt-4o-mini)

Demo corpus (2 PDFs, both open-access):
    1. "Attention Is All You Need" (Vaswani et al., 2017)
    2. "GPT-3: Language Models are Few-Shot Learners" (Brown et al., 2020)

Demo scenario:
    The agent answers questions like:
      "How does the Transformer paper define multi-head attention, and how
       have AI semiconductor stocks performed in the last 6 months?"
    — combining academic content with live market data in one answer.

Usage (PowerShell):
    $env:OPENAI_API_KEY = "sk-..."
    python -m src.main ingest
    python -m src.main ask "Your question here"
    python -m src.main demo                  # runs 3 canned scenarios
    python -m src.main chat                  # interactive REPL

Usage (bash/zsh):
    export OPENAI_API_KEY=sk-...
    python -m src.main ingest
    python -m src.main ask "Your question here"
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path

from openai import OpenAI

from .agent import FinancialAgent
from .rag_index import RagIndex
from .tools import build_tool_registry


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_ROOT / "data"
CHROMA_DIR = PROJECT_ROOT / "chroma_db"

# Demo corpus — both papers are openly accessible on arXiv.
CORPUS = [
    {
        "url": "https://arxiv.org/pdf/1706.03762",
        "filename": "attention_is_all_you_need.pdf",
        "title": "Attention Is All You Need (Vaswani et al., 2017)",
    },
    {
        "url": "https://arxiv.org/pdf/2005.14165",
        "filename": "gpt3_few_shot_learners.pdf",
        "title": "Language Models are Few-Shot Learners — GPT-3 (Brown et al., 2020)",
    },
]

# Three canned demo questions exercising different agent capabilities.
DEMO_QUESTIONS = [
    # Q1: Pure document RAG — should mostly use search_filings.
    "According to the Transformer paper, what is the purpose of multi-head "
    "attention, and how does the paper say it differs from single-head "
    "attention?",

    # Q2: Pure market — should mostly use market tools.
    "Compare 6-month performance of NVDA, AMD, and INTC. Which has the best "
    "risk-adjusted return based on a Sharpe-like metric over the past year?",

    # Q3: TRUE agentic — must combine docs + market data.
    "The Transformer and GPT-3 papers describe scaling model size as critical "
    "to performance. Given that, how have the largest 'AI infrastructure' "
    "stocks (NVDA, MSFT, GOOGL) performed over the last 6 months, and is "
    "there alignment between the academic argument for scale and recent "
    "market sentiment toward these companies?",
]


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("main")


# ---------------------------------------------------------------------------
# Pipeline operations
# ---------------------------------------------------------------------------

def cmd_ingest() -> None:
    """Download all corpus PDFs and index them into Chroma."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    rag = RagIndex(chroma_dir=CHROMA_DIR)

    for entry in CORPUS:
        dest = DATA_DIR / entry["filename"]
        try:
            RagIndex.download_pdf(entry["url"], dest)
            rag.ingest_pdf(dest)
        except Exception as e:  # noqa: BLE001
            log.error("Failed to ingest %s: %s", entry["filename"], e)

    log.info("✓ Ingest complete. Total chunks indexed: %d", rag.count())


def _make_agent() -> FinancialAgent:
    """Build a fully-wired FinancialAgent."""
    client = OpenAI()  # reads OPENAI_API_KEY
    rag = RagIndex(chroma_dir=CHROMA_DIR, openai_client=client)
    if rag.count() == 0:
        raise RuntimeError(
            "Index is empty. Run `python -m src.main ingest` first."
        )
    schemas, impls = build_tool_registry(rag)
    return FinancialAgent(
        openai_client=client,
        tool_schemas=schemas,
        tool_impls=impls,
    )


def cmd_ask(question: str) -> None:
    agent = _make_agent()
    print("\n" + "=" * 78)
    print(f"Q: {question}")
    print("=" * 78)
    result = agent.run(question)
    _print_trace_summary(result)
    print("\n--- Answer " + "-" * 67)
    print(result.answer)
    print("=" * 78 + "\n")


def cmd_demo() -> None:
    """Run all canned demo questions to exercise the agent end-to-end."""
    agent = _make_agent()
    for i, q in enumerate(DEMO_QUESTIONS, start=1):
        print("\n" + "#" * 78)
        print(f"# DEMO {i} of {len(DEMO_QUESTIONS)}")
        print("#" * 78)
        print(f"\nQ: {q}\n")
        result = agent.run(q)
        _print_trace_summary(result)
        print("\n--- Answer " + "-" * 67)
        print(result.answer)
        print()


def cmd_chat() -> None:
    """Interactive REPL."""
    agent = _make_agent()
    print("\nAgentic RAG REPL — ask anything (combines docs + live market data).")
    print("Commands: :q to quit\n")
    while True:
        try:
            q = input("agent> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return
        if not q:
            continue
        if q in (":q", ":quit", ":exit"):
            return
        try:
            result = agent.run(q)
            _print_trace_summary(result)
            print("\n--- Answer " + "-" * 67)
            print(result.answer)
            print()
        except Exception as e:  # noqa: BLE001
            log.error("Run failed: %s", e)


# ---------------------------------------------------------------------------
# Display helpers
# ---------------------------------------------------------------------------

def _print_trace_summary(result) -> None:
    print(f"\n[trace] {result.iterations} iteration(s)")
    for step in result.trace:
        if step.tool_calls:
            for tc in step.tool_calls:
                args_short = str(tc["arguments"])
                if len(args_short) > 80:
                    args_short = args_short[:77] + "..."
                print(f"  iter {step.iteration}  tool={tc['name']:<24s}  args={args_short}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _check_api_key() -> None:
    if not os.environ.get("OPENAI_API_KEY"):
        print("ERROR: OPENAI_API_KEY is not set. Export it before running.",
              file=sys.stderr)
        sys.exit(2)


def main() -> None:
    p = argparse.ArgumentParser(
        prog="agentic-rag",
        description="Agentic RAG: PyMuPDF + Chroma + OpenAI + yfinance",
    )
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("ingest", help="Download corpus PDFs and build index")
    p_ask = sub.add_parser("ask", help="Ask a single question")
    p_ask.add_argument("question", type=str)
    sub.add_parser("demo", help="Run 3 canned demo scenarios")
    sub.add_parser("chat", help="Interactive REPL")

    args = p.parse_args()
    _check_api_key()

    {
        "ingest": cmd_ingest,
        "ask": lambda: cmd_ask(args.question),
        "demo": cmd_demo,
        "chat": cmd_chat,
    }[args.cmd]()


if __name__ == "__main__":
    main()
