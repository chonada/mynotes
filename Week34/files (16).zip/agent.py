"""
================================================================================
The Agent
================================================================================

A ReAct-style agent built on OpenAI Chat Completions tool-calling. The loop:

    1. Send user question + tool definitions to the model.
    2. If the model returns tool_calls → execute them (in parallel-safe
       order), append results, re-prompt.
    3. If the model returns plain content → that's the final answer; return it.
    4. Cap iterations to prevent runaway loops.

Key engineering decisions
-------------------------
- **Parallel tool calls**: the model may emit multiple tool_calls in one
  turn; we execute them all and append a `tool` message per call_id. This
  cuts latency for naturally-parallel work (e.g., compare 3 stocks).

- **Strong system prompt**: the agent must (a) decide when to use docs vs.
  market data, (b) cite both sources, (c) say "insufficient data" when
  appropriate. Without this discipline, agents wander.

- **Step-by-step trace**: every iteration logs which tools were called and
  with what arguments. This is invaluable for debugging and for showing
  the user the agent's reasoning.

- **Defensive JSON parsing**: tool argument JSON sometimes has trailing
  whitespace, escapes, or other quirks. We normalize before parsing.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from typing import Any

from openai import OpenAI

log = logging.getLogger("agent.core")


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

CHAT_MODEL = "gpt-4o-mini"
MAX_ITERATIONS = 8     # hard cap on tool-call rounds
TEMPERATURE = 0.1


SYSTEM_PROMPT = """\
You are a financial research analyst agent. You help the user combine
academic / research-paper knowledge with live market data to answer
investment-related questions.

You have access to tools in two categories:

DOCUMENT TOOLS
  - search_filings(query, top_k): semantic search over an indexed corpus of
    research papers. Use for any question about concepts, definitions,
    methods, claims, or findings in the documents.

MARKET TOOLS (live data via Yahoo Finance)
  - get_stock_quote(ticker): current price + fundamentals (P/E, market cap,
    beta, 52-week range, sector, industry).
  - get_price_history(ticker, period): summary of historical price action
    over a window — total return, max drawdown, momentum vs. mean.
  - calculate_risk_metrics(ticker, period): annualized return, volatility,
    and a Sharpe-like ratio.
  - compare_tickers(tickers, period): side-by-side ranking of 2–6 tickers
    by total return.

DECISION RULES
1. PLAN before acting. For a multi-part question, list the sub-questions
   internally and call the right tool for each.
2. Use document tools for "what does the paper say" questions; market tools
   for "what is the price / how has X performed" questions; both when the
   question requires combining them.
3. Make tool calls in PARALLEL when sub-tasks are independent (e.g., quotes
   for several tickers).
4. CITE in your final answer:
   - For document facts:  [doc:<filename> p.<N>]
   - For market data:     [market: <ticker> as_of <date>]
5. If a tool returns an error, try once with a corrected argument; if it
   still fails, report the failure plainly and proceed with what you have.
6. NEVER fabricate numbers. If the data isn't available, say so.
7. Keep final answers focused: 4–10 sentences for narrow questions, up to
   ~15 for multi-part research questions. Use short bullet points only when
   genuinely helpful.

After your final answer, you may add a short "Tools used:" line listing the
tools you called, for transparency.
"""


# ---------------------------------------------------------------------------
# Trace
# ---------------------------------------------------------------------------

@dataclass
class TraceStep:
    """One iteration of the agent loop, captured for inspection."""
    iteration: int
    tool_calls: list[dict] = field(default_factory=list)
    assistant_text: str | None = None


@dataclass
class AgentResult:
    answer: str
    iterations: int
    trace: list[TraceStep]


# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------

class FinancialAgent:
    """ReAct-style agent that orchestrates document RAG + market-data tools."""

    def __init__(
        self,
        openai_client: OpenAI,
        tool_schemas: list[dict],
        tool_impls: dict[str, Any],
        model: str = CHAT_MODEL,
        max_iterations: int = MAX_ITERATIONS,
    ):
        self.client = openai_client
        self.tool_schemas = tool_schemas
        self.tool_impls = tool_impls
        self.model = model
        self.max_iterations = max_iterations

    # -------------------------------------------------------------------

    def run(self, question: str, verbose: bool = True) -> AgentResult:
        """
        Drive the agent loop until the model emits a final answer or we hit
        the iteration cap.
        """
        messages: list[dict] = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": question},
        ]
        trace: list[TraceStep] = []

        for it in range(1, self.max_iterations + 1):
            log.info("--- Iteration %d ---", it)
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                tools=self.tool_schemas,
                tool_choice="auto",
                temperature=TEMPERATURE,
            )
            msg = response.choices[0].message

            # Always append the assistant message — even if it only contains
            # tool_calls — so the API can match tool replies to their calls.
            messages.append(msg.model_dump(exclude_unset=True, exclude_none=True))

            step = TraceStep(iteration=it, assistant_text=msg.content)

            if msg.tool_calls:
                # Execute every requested tool call (parallel calls allowed).
                for tc in msg.tool_calls:
                    name = tc.function.name
                    raw_args = tc.function.arguments or "{}"
                    try:
                        args = json.loads(raw_args)
                    except json.JSONDecodeError as e:
                        result = {"error": f"Could not parse tool arguments: {e}",
                                  "raw_arguments": raw_args}
                    else:
                        result = self._execute_tool(name, args)

                    step.tool_calls.append({
                        "id": tc.id,
                        "name": name,
                        "arguments": args if isinstance(result, dict) and "raw_arguments" not in result else raw_args,
                        "result_preview": _preview(result),
                    })

                    messages.append({
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "name": name,
                        "content": json.dumps(result, default=str),
                    })

                if verbose:
                    self._log_step(step)
                trace.append(step)
                continue  # let the model see tool results next iteration

            # No tool calls → the model has produced a final answer.
            if verbose:
                self._log_step(step)
            trace.append(step)
            return AgentResult(
                answer=(msg.content or "").strip(),
                iterations=it,
                trace=trace,
            )

        # Iteration cap hit. Force one more call WITHOUT tools so the model
        # must summarise from what it has.
        log.warning("Hit max iterations (%d); forcing summary.", self.max_iterations)
        messages.append({
            "role": "user",
            "content": (
                "You've reached the tool-call iteration limit. Provide your best "
                "answer using only the information you have so far. Acknowledge "
                "any gaps clearly."
            ),
        })
        response = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=TEMPERATURE,
        )
        final = response.choices[0].message.content or ""
        return AgentResult(
            answer=final.strip(),
            iterations=self.max_iterations,
            trace=trace,
        )

    # -------------------------------------------------------------------

    def _execute_tool(self, name: str, args: dict) -> Any:
        if name not in self.tool_impls:
            return {"error": f"Unknown tool '{name}'."}
        try:
            log.info("→ tool %s(%s)", name, _short(args))
            return self.tool_impls[name](**args)
        except TypeError as e:
            # Wrong argument names/types — let the model retry with better args.
            return {"error": f"Bad arguments for {name}: {e}"}
        except Exception as e:  # noqa: BLE001
            log.exception("Tool %s raised", name)
            return {"error": f"{name} raised: {e}"}

    def _log_step(self, step: TraceStep) -> None:
        if step.tool_calls:
            for tc in step.tool_calls:
                log.info("   ↳ called %s(%s) → %s",
                         tc["name"], _short(tc["arguments"]), tc["result_preview"])
        if step.assistant_text:
            preview = step.assistant_text[:200].replace("\n", " ")
            log.info("   ↳ assistant: %s%s",
                     preview, "…" if len(step.assistant_text) > 200 else "")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _preview(obj: Any, n: int = 240) -> str:
    """Stringify a tool result compactly for trace logging."""
    try:
        s = json.dumps(obj, default=str)
    except Exception:
        s = str(obj)
    return (s[:n] + "…") if len(s) > n else s


def _short(args: Any, n: int = 120) -> str:
    s = json.dumps(args, default=str) if not isinstance(args, str) else args
    return (s[:n] + "…") if len(s) > n else s
