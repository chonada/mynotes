"""
================================================================================
RAG Index
================================================================================

Standalone PDF → chunks → embeddings → Chroma index.

Compared with the naive RAG demo, this module:
    1. Supports MULTIPLE PDFs in a corpus (each chunk carries a source name).
    2. Exposes a clean `RagIndex` class so the agent can hold one instance
       and call `.search()` from a tool function.
    3. Returns retrievals with source attribution so the agent can cite both
       the document AND the page.
"""

from __future__ import annotations

import hashlib
import logging
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable
from urllib.request import Request, urlopen

import chromadb
import fitz  # PyMuPDF
from chromadb.config import Settings
from openai import OpenAI

log = logging.getLogger("agent.rag")


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

EMBED_MODEL = "text-embedding-3-small"  # 1536-d, cheap, strong
CHUNK_WORDS = 220
CHUNK_OVERLAP_WORDS = 40
EMBED_BATCH = 64
COLLECTION_NAME = "agent_corpus"


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class Chunk:
    chunk_id: str
    text: str
    source: str       # filename of the source PDF
    page: int         # 1-indexed
    chunk_index: int


@dataclass
class Retrieval:
    chunk_id: str
    text: str
    source: str
    page: int
    distance: float


# ---------------------------------------------------------------------------
# RagIndex
# ---------------------------------------------------------------------------

class RagIndex:
    """
    Encapsulates a Chroma-backed corpus + OpenAI embedder.

    Typical lifecycle:
        idx = RagIndex(chroma_dir=Path("./chroma_db"))
        idx.ingest_pdf(Path("./data/some_paper.pdf"))
        idx.ingest_pdf(Path("./data/another_paper.pdf"))
        hits = idx.search("what is multi-head attention?", top_k=4)
    """

    def __init__(self, chroma_dir: Path, openai_client: OpenAI | None = None):
        self.chroma_dir = chroma_dir
        self.chroma_dir.mkdir(parents=True, exist_ok=True)
        self.client = openai_client or OpenAI()  # reads OPENAI_API_KEY

        chroma_client = chromadb.PersistentClient(
            path=str(self.chroma_dir),
            settings=Settings(anonymized_telemetry=False, allow_reset=True),
        )
        # Cosine space matches OpenAI's L2-normalized embeddings.
        self.collection = chroma_client.get_or_create_collection(
            name=COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"},
        )

    # ----- ingestion ------------------------------------------------------

    def ingest_pdf(self, pdf_path: Path) -> int:
        """
        Read PDF → clean → chunk → embed → upsert. Returns # of chunks added.

        Idempotent: chunk IDs are content-addressed, so re-ingesting the
        same PDF replaces existing chunks without duplication.
        """
        if not pdf_path.exists():
            raise FileNotFoundError(pdf_path)

        log.info("Ingesting %s", pdf_path.name)
        pages = self._extract_pages(pdf_path)
        chunks = self._chunk_pages(pages, source=pdf_path.name)

        if not chunks:
            log.warning("No chunks built from %s", pdf_path.name)
            return 0

        embeddings = self._embed([c.text for c in chunks])
        self.collection.upsert(
            ids=[c.chunk_id for c in chunks],
            documents=[c.text for c in chunks],
            embeddings=embeddings,
            metadatas=[
                {"source": c.source, "page": c.page, "chunk_index": c.chunk_index}
                for c in chunks
            ],
        )
        log.info("Indexed %d chunks from %s; collection now has %d total",
                 len(chunks), pdf_path.name, self.collection.count())
        return len(chunks)

    @staticmethod
    def download_pdf(url: str, dest: Path) -> Path:
        """Convenience: download a PDF if it's not already on disk."""
        dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.exists() and dest.stat().st_size > 0:
            log.info("Already on disk: %s", dest)
            return dest
        log.info("Downloading %s", url)
        req = Request(url, headers={"User-Agent": "agentic-rag/1.0"})
        with urlopen(req, timeout=60) as r, open(dest, "wb") as f:
            f.write(r.read())
        log.info("Saved %s (%d bytes)", dest, dest.stat().st_size)
        return dest

    # ----- retrieval ------------------------------------------------------

    def search(self, query: str, top_k: int = 4) -> list[Retrieval]:
        if self.collection.count() == 0:
            return []
        [vec] = self._embed([query])
        results = self.collection.query(
            query_embeddings=[vec],
            n_results=top_k,
            include=["documents", "metadatas", "distances"],
        )
        hits: list[Retrieval] = []
        for cid, text, meta, dist in zip(
            results["ids"][0],
            results["documents"][0],
            results["metadatas"][0],
            results["distances"][0],
        ):
            hits.append(Retrieval(
                chunk_id=cid,
                text=text,
                source=str(meta.get("source", "?")),
                page=int(meta.get("page", -1)),
                distance=float(dist),
            ))
        return hits

    def count(self) -> int:
        return self.collection.count()

    # ----- internals ------------------------------------------------------

    @staticmethod
    def _extract_pages(pdf_path: Path) -> list[tuple[int, str]]:
        out: list[tuple[int, str]] = []
        with fitz.open(pdf_path) as doc:
            for i, page in enumerate(doc, start=1):
                cleaned = RagIndex._clean(page.get_text("text"))
                if cleaned:
                    out.append((i, cleaned))
        return out

    @staticmethod
    def _clean(s: str) -> str:
        s = re.sub(r"-\n(\w)", r"\1", s)        # de-hyphenate line breaks
        s = re.sub(r"(?<!\n)\n(?!\n)", " ", s)  # paragraph wrapping → spaces
        s = re.sub(r"[ \t]+", " ", s)
        s = re.sub(r"\n{3,}", "\n\n", s)
        return s.strip()

    @staticmethod
    def _chunk_pages(
        pages: list[tuple[int, str]],
        source: str,
        chunk_words: int = CHUNK_WORDS,
        overlap_words: int = CHUNK_OVERLAP_WORDS,
    ) -> list[Chunk]:
        chunks: list[Chunk] = []
        idx = 0
        stride = chunk_words - overlap_words
        for page_num, text in pages:
            words = text.split()
            if not words:
                continue
            if len(words) <= chunk_words:
                chunks.append(RagIndex._mk(words, source, page_num, idx))
                idx += 1
                continue
            for start in range(0, len(words), stride):
                window = words[start : start + chunk_words]
                if len(window) < 30:
                    break
                chunks.append(RagIndex._mk(window, source, page_num, idx))
                idx += 1
                if start + chunk_words >= len(words):
                    break
        return chunks

    @staticmethod
    def _mk(words: Iterable[str], source: str, page: int, idx: int) -> Chunk:
        text = " ".join(words)
        digest = hashlib.sha1(f"{source}:{page}:{idx}:{text}".encode()).hexdigest()[:16]
        return Chunk(
            chunk_id=f"{source}_{idx:04d}_{digest}",
            text=text,
            source=source,
            page=page,
            chunk_index=idx,
        )

    def _embed(self, texts: list[str]) -> list[list[float]]:
        out: list[list[float]] = []
        for i in range(0, len(texts), EMBED_BATCH):
            batch = texts[i : i + EMBED_BATCH]
            log.info("Embedding %d–%d (n=%d)", i, i + len(batch), len(batch))
            out.extend(self._embed_with_retry(batch))
        return out

    def _embed_with_retry(self, batch: list[str], attempts: int = 5) -> list[list[float]]:
        delay = 1.0
        for k in range(1, attempts + 1):
            try:
                resp = self.client.embeddings.create(model=EMBED_MODEL, input=batch)
                return [d.embedding for d in resp.data]
            except Exception as e:  # noqa: BLE001
                if k == attempts:
                    raise
                log.warning("Embed attempt %d failed (%s); retry in %.1fs",
                            k, e.__class__.__name__, delay)
                time.sleep(delay)
                delay *= 2
        raise RuntimeError("unreachable")  # pragma: no cover
