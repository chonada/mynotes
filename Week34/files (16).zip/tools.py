"""
================================================================================
Agent Tools
================================================================================

The capabilities the agent can invoke. Each tool is:
    1. A regular Python function with typed parameters and JSON-serializable
       return values.
    2. Accompanied by a JSON Schema describing it to the LLM.

Tools fall into two categories:
    - DOCUMENT TOOLS  → search_filings()           (RAG over our PDF corpus)
    - MARKET TOOLS    → get_stock_quote(),
                        get_price_history(),
                        calculate_risk_metrics(),
                        compare_tickers()           (live yfinance data)

Design notes
------------
- Tools NEVER raise to the agent loop; they catch and return {"error": "..."}
  dicts. The LLM is good at recovering from explicit error messages and bad
  at recovering from unhandled exceptions.
- All return values are plain dicts/lists — JSON-serializable so they round-
  trip through the chat completions API cleanly.
- Numerical outputs are rounded to keep token usage low and make answers
  more readable.
"""

from __future__ import annotations

import logging
import math
import statistics
from datetime import datetime
from typing import Any

import yfinance as yf

from .rag_index import RagIndex

log = logging.getLogger("agent.tools")


# ---------------------------------------------------------------------------
# Tool registry
# ---------------------------------------------------------------------------
# We expose tools via `build_tool_registry(rag)` at the bottom of this module.
# That function returns (schemas_for_llm, name_to_callable), with the RAG
# index injected into search_filings via a closure. This keeps state out of
# module globals.


# ---------------------------------------------------------------------------
# 1. DOCUMENT TOOL — search_filings
# ---------------------------------------------------------------------------

def _make_search_filings(rag: RagIndex):
    """
    Closure factory: binds the RAG index to the tool implementation.

    We use a closure so the tool function signature stays clean (no `rag`
    parameter visible to the LLM), while still injecting the index instance.
    """

    def search_filings(query: str, top_k: int = 4) -> dict:
        """Retrieve relevant excerpts from the indexed document corpus."""
        try:
            top_k = max(1, min(int(top_k), 10))
            hits = rag.search(query, top_k=top_k)
            return {
                "query": query,
                "results": [
                    {
                        "page": h.page,
                        "score": round(1 - h.distance, 4),  # similarity, not distance
                        "text": h.text,
                    }
                    for h in hits
                ],
            }
        except Exception as e:  # noqa: BLE001
            log.exception("search_filings failed")
            return {"error": f"search_filings failed: {e}"}

    return search_filings


SEARCH_FILINGS_SCHEMA = {
    "type": "function",
    "function": {
        "name": "search_filings",
        "description": (
            "Search the indexed research-paper corpus using semantic retrieval. "
            "Use this for any question about content of the documents — concepts, "
            "definitions, methods, results, claims. Returns excerpts with page numbers."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Natural-language search query.",
                },
                "top_k": {
                    "type": "integer",
                    "description": "Number of excerpts to return (1–10). Default 4.",
                    "default": 4,
                },
            },
            "required": ["query"],
        },
    },
}


# ---------------------------------------------------------------------------
# 2. MARKET TOOLS — yfinance
# ---------------------------------------------------------------------------

def _safe_ticker(ticker: str) -> yf.Ticker:
    """Sanitize and instantiate a yfinance Ticker object."""
    return yf.Ticker(ticker.strip().upper())


def get_stock_quote(ticker: str) -> dict:
    """
    Fetch live (15-min delayed) quote and key fundamentals for a US-listed
    equity.

    yfinance's `.info` is comprehensive but flaky — many fields are missing
    for some tickers, so we defensively `.get()` everything.
    """
    try:
        t = _safe_ticker(ticker)
        info = t.info or {}
        if not info or not info.get("symbol"):
            return {"error": f"No data found for ticker '{ticker}'."}

        price = info.get("regularMarketPrice") or info.get("currentPrice")
        prev = info.get("regularMarketPreviousClose") or info.get("previousClose")
        change_pct = None
        if price and prev:
            change_pct = round(((price - prev) / prev) * 100, 2)

        return {
            "ticker": info.get("symbol", ticker.upper()),
            "name": info.get("shortName") or info.get("longName"),
            "price": price,
            "previous_close": prev,
            "day_change_pct": change_pct,
            "currency": info.get("currency", "USD"),
            "market_cap": info.get("marketCap"),
            "pe_ratio_trailing": info.get("trailingPE"),
            "pe_ratio_forward": info.get("forwardPE"),
            "beta": info.get("beta"),
            "dividend_yield": info.get("dividendYield"),
            "52_week_high": info.get("fiftyTwoWeekHigh"),
            "52_week_low": info.get("fiftyTwoWeekLow"),
            "sector": info.get("sector"),
            "industry": info.get("industry"),
            "as_of": datetime.utcnow().isoformat(timespec="seconds") + "Z",
        }
    except Exception as e:  # noqa: BLE001
        log.exception("get_stock_quote failed")
        return {"error": f"get_stock_quote failed for {ticker}: {e}"}


GET_QUOTE_SCHEMA = {
    "type": "function",
    "function": {
        "name": "get_stock_quote",
        "description": (
            "Get the current price and key fundamentals (P/E, market cap, beta, "
            "52-week range, sector) for a US-listed stock. Use this to ground "
            "claims about valuation or recent price action in real data."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "ticker": {
                    "type": "string",
                    "description": "Stock ticker symbol (e.g., AAPL, NVDA, MSFT).",
                },
            },
            "required": ["ticker"],
        },
    },
}


# ---------------------------------------------------------------------------

def get_price_history(ticker: str, period: str = "6mo") -> dict:
    """
    Return a compact summary of historical price action: total return, max
    drawdown, simple momentum signal.

    We DO NOT return the full price series — the LLM doesn't benefit from
    raw rows, and they'd burn tokens. Summary stats are far more useful.
    """
    try:
        valid_periods = {"1mo", "3mo", "6mo", "1y", "2y", "5y", "ytd", "max"}
        if period not in valid_periods:
            return {"error": f"Invalid period '{period}'. Use one of {sorted(valid_periods)}."}

        t = _safe_ticker(ticker)
        df = t.history(period=period, interval="1d", auto_adjust=True)
        if df.empty:
            return {"error": f"No price history for {ticker} (period={period})."}

        closes = df["Close"].dropna().tolist()
        if len(closes) < 2:
            return {"error": f"Insufficient price points for {ticker}."}

        start, end = closes[0], closes[-1]
        total_return_pct = round(((end - start) / start) * 100, 2)

        # Max drawdown: worst peak-to-trough during the period.
        peak = closes[0]
        max_dd = 0.0
        for px in closes:
            if px > peak:
                peak = px
            dd = (px - peak) / peak
            if dd < max_dd:
                max_dd = dd

        # Simple momentum: are we above/below the period mean?
        avg = sum(closes) / len(closes)
        momentum = "above_average" if end > avg else "below_average"

        return {
            "ticker": ticker.upper(),
            "period": period,
            "start_date": str(df.index[0].date()),
            "end_date": str(df.index[-1].date()),
            "start_price": round(start, 2),
            "end_price": round(end, 2),
            "total_return_pct": total_return_pct,
            "max_drawdown_pct": round(max_dd * 100, 2),
            "period_mean_price": round(avg, 2),
            "momentum_vs_mean": momentum,
            "trading_days": len(closes),
        }
    except Exception as e:  # noqa: BLE001
        log.exception("get_price_history failed")
        return {"error": f"get_price_history failed for {ticker}: {e}"}


GET_HISTORY_SCHEMA = {
    "type": "function",
    "function": {
        "name": "get_price_history",
        "description": (
            "Summarize historical price action: total return, max drawdown, and "
            "momentum signal over a given period. Useful for assessing recent "
            "performance and risk."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "ticker": {"type": "string", "description": "Stock ticker symbol."},
                "period": {
                    "type": "string",
                    "enum": ["1mo", "3mo", "6mo", "1y", "2y", "5y", "ytd", "max"],
                    "description": "Lookback window. Default '6mo'.",
                    "default": "6mo",
                },
            },
            "required": ["ticker"],
        },
    },
}


# ---------------------------------------------------------------------------

def calculate_risk_metrics(ticker: str, period: str = "1y") -> dict:
    """
    Compute simple ex-post risk metrics from daily returns: annualized
    volatility and a Sharpe-like ratio assuming 0% risk-free rate.

    These are educational approximations — production risk analytics would
    use rolling windows, regime adjustment, and a proper risk-free curve.
    """
    try:
        t = _safe_ticker(ticker)
        df = t.history(period=period, interval="1d", auto_adjust=True)
        if df.empty or len(df) < 30:
            return {"error": f"Insufficient data for {ticker} risk metrics."}

        closes = df["Close"].dropna().tolist()
        # Daily log returns are more theoretically clean than simple returns.
        rets = [math.log(closes[i] / closes[i - 1]) for i in range(1, len(closes))]
        if not rets:
            return {"error": "No returns computed."}

        daily_mean = statistics.fmean(rets)
        daily_std = statistics.stdev(rets) if len(rets) > 1 else 0.0
        ann_vol = daily_std * math.sqrt(252)
        ann_return = daily_mean * 252
        sharpe = (ann_return / ann_vol) if ann_vol > 0 else None

        return {
            "ticker": ticker.upper(),
            "period": period,
            "annualized_return_pct": round(ann_return * 100, 2),
            "annualized_volatility_pct": round(ann_vol * 100, 2),
            "sharpe_like_ratio": round(sharpe, 2) if sharpe is not None else None,
            "observations": len(rets),
            "note": "Sharpe-like assumes 0% risk-free rate. Educational use only.",
        }
    except Exception as e:  # noqa: BLE001
        log.exception("calculate_risk_metrics failed")
        return {"error": f"calculate_risk_metrics failed for {ticker}: {e}"}


CALC_RISK_SCHEMA = {
    "type": "function",
    "function": {
        "name": "calculate_risk_metrics",
        "description": (
            "Calculate ex-post risk metrics (annualized volatility, return, "
            "Sharpe-like ratio) from historical daily returns."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "ticker": {"type": "string"},
                "period": {
                    "type": "string",
                    "enum": ["3mo", "6mo", "1y", "2y", "5y"],
                    "default": "1y",
                },
            },
            "required": ["ticker"],
        },
    },
}


# ---------------------------------------------------------------------------

def compare_tickers(tickers: list[str], period: str = "6mo") -> dict:
    """
    Side-by-side comparison of multiple tickers over the same period.

    Returns one row per ticker with return, drawdown, and end-of-period
    snapshot. Lets the agent reason about relative performance in one call
    instead of N round-trips.
    """
    if not tickers or not isinstance(tickers, list):
        return {"error": "Provide a non-empty list of ticker symbols."}
    if len(tickers) > 6:
        return {"error": "Compare at most 6 tickers per call."}

    rows = []
    for tk in tickers:
        h = get_price_history(tk, period=period)
        if "error" in h:
            rows.append({"ticker": tk.upper(), "error": h["error"]})
            continue
        rows.append({
            "ticker": h["ticker"],
            "total_return_pct": h["total_return_pct"],
            "max_drawdown_pct": h["max_drawdown_pct"],
            "end_price": h["end_price"],
            "momentum_vs_mean": h["momentum_vs_mean"],
        })

    # Rank by return for the agent's convenience.
    ranked = sorted(
        [r for r in rows if "error" not in r],
        key=lambda r: r["total_return_pct"],
        reverse=True,
    )
    for i, r in enumerate(ranked, start=1):
        r["rank_by_return"] = i

    return {
        "period": period,
        "comparison": rows,
        "best_performer": ranked[0]["ticker"] if ranked else None,
        "worst_performer": ranked[-1]["ticker"] if ranked else None,
    }


COMPARE_SCHEMA = {
    "type": "function",
    "function": {
        "name": "compare_tickers",
        "description": (
            "Compare 2–6 tickers side by side over the same period. Returns "
            "per-ticker return, drawdown, and a ranking by total return."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "tickers": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of 2–6 ticker symbols to compare.",
                    "minItems": 2,
                    "maxItems": 6,
                },
                "period": {
                    "type": "string",
                    "enum": ["1mo", "3mo", "6mo", "1y", "2y", "5y", "ytd"],
                    "default": "6mo",
                },
            },
            "required": ["tickers"],
        },
    },
}


# ---------------------------------------------------------------------------
# Registration (after all schemas + impls defined)
# ---------------------------------------------------------------------------

def build_tool_registry(rag: RagIndex) -> tuple[list[dict], dict]:
    """
    Return (schemas_for_llm, name_to_callable) bound to the given RAG index.

    Called once at agent startup. Keeps the RAG instance from being a global.
    """
    schemas: list[dict] = []
    impls: dict[str, Any] = {}

    def _add(schema: dict, fn):
        schemas.append(schema)
        impls[schema["function"]["name"]] = fn

    _add(SEARCH_FILINGS_SCHEMA, _make_search_filings(rag))
    _add(GET_QUOTE_SCHEMA, get_stock_quote)
    _add(GET_HISTORY_SCHEMA, get_price_history)
    _add(CALC_RISK_SCHEMA, calculate_risk_metrics)
    _add(COMPARE_SCHEMA, compare_tickers)

    return schemas, impls
