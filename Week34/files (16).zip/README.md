# Agentic RAG — Financial Research Agent

A real **agentic** RAG system that goes beyond naive retrieve-then-generate.
The agent **plans**, **chooses tools**, **executes them** (sometimes in
parallel), **observes results**, and **iterates** until it has enough
information to answer.

## Why this is *agentic*, not naive

| Aspect            | Naive RAG                     | Agentic RAG (this project)                                   |
| ----------------- | ----------------------------- | ------------------------------------------------------------ |
| Control flow      | Fixed: embed → retrieve → gen | Dynamic: LLM decides which tools to call and in what order   |
| Data sources      | One vector store              | Multiple — vector store **plus** live market-data APIs       |
| Iterations        | Always 1                      | Up to 8, with the model deciding when it has enough          |
| Tool selection    | None                          | LLM picks from 5 tools per turn, may call several in parallel |
| Failure handling  | None                          | Tool errors fed back to LLM, which retries with corrections  |

## Architecture

```
            ┌──────────────────────────────────────────────────────┐
            │                User question                          │
            └────────────────────────┬─────────────────────────────┘
                                     ▼
            ┌──────────────────────────────────────────────────────┐
            │             FinancialAgent (gpt-4o-mini)              │
            │   ReAct loop: plan → call tools → observe → repeat    │
            └──┬─────────┬──────────┬──────────────┬────────────────┘
               ▼         ▼          ▼              ▼
       search_filings  get_quote  get_history  compare_tickers
        (Chroma+RAG)   (yfinance) (yfinance)   (yfinance)
                            │           │              │
                       calculate_risk_metrics ─────────┘
                            (yfinance)

   Document corpus (Chroma):                  Live market data:
   • Attention Is All You Need                • Real-time quotes
   • GPT-3 Few-Shot Learners                  • Historical prices
                                              • Risk metrics (vol, Sharpe)
```

## The 5 tools

| Tool                      | Purpose                                                      |
| ------------------------- | ------------------------------------------------------------ |
| `search_filings`          | Semantic search over the indexed PDF corpus (Chroma + OpenAI embeddings) |
| `get_stock_quote`         | Live price + fundamentals (P/E, market cap, beta, sector)    |
| `get_price_history`       | Total return, max drawdown, momentum signal                  |
| `calculate_risk_metrics`  | Annualized volatility, return, Sharpe-like ratio             |
| `compare_tickers`         | Side-by-side ranking of 2–6 tickers by return                |

The agent decides which to call. For a multi-stock comparison it'll fire
`compare_tickers` once instead of N `get_stock_quote` calls. For a question
that mixes paper content and stock data, it'll interleave `search_filings`
with market tools.

## Setup

```bash
python -m venv .venv && source .venv/bin/activate    # or .venv\Scripts\activate on Windows
pip install -r requirements.txt
export OPENAI_API_KEY=sk-...                         # PowerShell: $env:OPENAI_API_KEY = "sk-..."
```

## 1. Ingest the corpus (one-time)

Downloads two arXiv PDFs and builds the Chroma index.

```bash
python -m src.main ingest
```

## 2. Try the canned demo

Three pre-written questions exercising different agent behaviors.

```bash
python -m src.main demo
```

The three demos:

1. **Pure document RAG** — "What is multi-head attention?"
   Agent should mostly call `search_filings`.

2. **Pure market data** — "Compare 6-month performance of NVDA, AMD, INTC."
   Agent should call `compare_tickers` and `calculate_risk_metrics`.

3. **True agentic mix** — "Given the papers' argument for scale, how have
   NVDA, MSFT, GOOGL performed lately?"
   Agent must combine `search_filings` with multiple market tools, often
   in parallel.

## 3. Ask your own questions

```bash
python -m src.main ask "Your question here"
```

Examples that exercise the agent well:
- "What does GPT-3 say about emergent abilities, and is NVDA's P/E ratio justified by its growth?"
- "Compare TSLA risk metrics over 1 year to the S&P 500's recent volatility, and explain what 'attention' means in the Transformer paper."
- "Was multi-head attention introduced in 2017? What's the current price of GOOGL?"

## 4. Interactive REPL

```bash
python -m src.main chat
```

## What the trace shows

Every run prints a per-iteration trace, e.g.:

```
[trace] 3 iteration(s)
  iter 1  tool=search_filings        args={'query': 'multi-head attention'}
  iter 1  tool=compare_tickers       args={'tickers': ['NVDA', 'MSFT', 'GOOGL'], 'period': '6mo'}
  iter 2  tool=calculate_risk_metrics args={'ticker': 'NVDA', 'period': '1y'}
```

This is your window into what the agent is actually doing — invaluable for
debugging prompts, tool descriptions, or unexpected behaviour.

## Project layout

```
agentic-rag/
├── src/
│   ├── __init__.py
│   ├── rag_index.py     # PyMuPDF → Chroma → OpenAI embeddings
│   ├── tools.py         # 5 agent-callable tools + JSON schemas
│   ├── agent.py         # ReAct-style tool-calling loop
│   └── main.py          # CLI entry point
├── data/                # downloaded PDFs (created on first ingest)
├── chroma_db/           # vector store (created on first ingest)
├── requirements.txt
└── README.md
```

## Cost

Per `demo` run (3 questions, full ingest already done): roughly
**$0.005–$0.015** with `gpt-4o-mini`. Embedding the corpus is essentially
free (a few cents) since `text-embedding-3-small` is $0.02 per 1M tokens.

## What you can extend

- **Add tools**: web search, SEC EDGAR lookup, options chain, FX rates.
- **Multi-agent**: separate "researcher" + "writer" agents communicating via shared state.
- **Memory**: persist conversations across runs (write trace to disk; replay on `chat`).
- **Reranker**: add a Cohere rerank step inside `search_filings` for higher precision.
- **Evals**: golden-set evaluation comparing agent answers against expected sources.
