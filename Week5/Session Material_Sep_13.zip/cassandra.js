-- =====================================================
-- CASSANDRA COMPREHENSIVE EXAMPLES
-- =====================================================

-- 1. KEYSPACE OPERATIONS
-- =====================================================
-- Create a keyspace (similar to database in SQL)
CREATE KEYSPACE company
WITH replication = {
  'class': 'SimpleStrategy',
  'replication_factor': 3
};

-- Use the keyspace
USE company;

-- Show all keyspaces
DESCRIBE KEYSPACES;

-- 2. BASIC TABLE OPERATIONS
-- =====================================================
-- Create table with primary key
CREATE TABLE EMPLOYEE (
  empId int PRIMARY KEY,
  name text,
  dept text,
  salary decimal,
  hire_date date,
  email text
);

-- Insert data
INSERT INTO EMPLOYEE(empId, name, dept, salary, hire_date, email) 
VALUES (0001, 'Clark', 'Sales', 50000, '2023-01-15', 'clark@company.com');

INSERT INTO EMPLOYEE(empId, name, dept, salary, hire_date, email) 
VALUES (0002, 'Dave', 'Accounting', 55000, '2022-03-10', 'dave@company.com');

INSERT INTO EMPLOYEE(empId, name, dept, salary, hire_date, email) 
VALUES (0003, 'Ava', 'Sales', 48000, '2023-06-20', 'ava@company.com');

INSERT INTO EMPLOYEE(empId, name, dept, salary, hire_date, email) 
VALUES (0004, 'Emma', 'Engineering', 75000, '2021-09-05', 'emma@company.com');

-- Basic select operations
SELECT * FROM EMPLOYEE;
SELECT name, dept FROM EMPLOYEE WHERE empId = 0001;

-- 3. COMPOSITE KEYS AND CLUSTERING
-- =====================================================
-- Table with composite primary key
CREATE TABLE EMPLOYEE_PROJECTS (
  empId int,
  project_name text,
  start_date date,
  end_date date,
  status text,
  PRIMARY KEY (empId, project_name)
);

-- Insert project data
INSERT INTO EMPLOYEE_PROJECTS(empId, project_name, start_date, end_date, status)
VALUES (0001, 'Website Redesign', '2024-01-01', '2024-03-31', 'completed');

INSERT INTO EMPLOYEE_PROJECTS(empId, project_name, start_date, end_date, status)
VALUES (0001, 'Mobile App', '2024-04-01', '2024-08-31', 'in_progress');

INSERT INTO EMPLOYEE_PROJECTS(empId, project_name, start_date, end_date, status)
VALUES (0002, 'Audit 2024', '2024-01-15', '2024-02-28', 'completed');

-- Query with composite key
SELECT * FROM EMPLOYEE_PROJECTS WHERE empId = 0001;
SELECT * FROM EMPLOYEE_PROJECTS WHERE empId = 0001 AND project_name = 'Mobile App';

-- 4. COLLECTIONS (Sets, Lists, Maps)
-- =====================================================
-- Table with collection types
CREATE TABLE EMPLOYEE_SKILLS (
  empId int PRIMARY KEY,
  name text,
  skills set<text>,
  certifications list<text>,
  performance_ratings map<int, decimal>
);

-- Insert data with collections
INSERT INTO EMPLOYEE_SKILLS(empId, name, skills, certifications, performance_ratings)
VALUES (0001, 'Clark', {'sales', 'negotiation', 'crm'}, 
        ['Sales Pro Cert', 'Customer Relations'], 
        {2023: 4.2, 2022: 4.0});

INSERT INTO EMPLOYEE_SKILLS(empId, name, skills, certifications, performance_ratings)
VALUES (0004, 'Emma', {'java', 'python', 'docker', 'kubernetes'}, 
        ['AWS Certified', 'Java Expert', 'Scrum Master'], 
        {2023: 4.8, 2022: 4.5, 2021: 4.3});

-- Update collections
UPDATE EMPLOYEE_SKILLS 
SET skills = skills + {'leadership'} 
WHERE empId = 0001;

-- Query collections
SELECT name, skills FROM EMPLOYEE_SKILLS WHERE empId = 0004;

-- 5. TIME-SERIES DATA WITH TIME UUID
-- =====================================================
-- Table for time-series data (logs, events)
CREATE TABLE EMPLOYEE_ACTIVITY_LOG (
  empId int,
  log_time timeuuid,
  activity text,
  details text,
  PRIMARY KEY (empId, log_time)
) WITH CLUSTERING ORDER BY (log_time DESC);

-- Insert time-series data
INSERT INTO EMPLOYEE_ACTIVITY_LOG(empId, log_time, activity, details)
VALUES (0001, now(), 'login', 'User logged in from IP 192.168.1.100');

INSERT INTO EMPLOYEE_ACTIVITY_LOG(empId, log_time, activity, details)
VALUES (0001, now(), 'document_access', 'Accessed quarterly report');

-- Query recent activities
SELECT activity, details, dateOf(log_time) as timestamp 
FROM EMPLOYEE_ACTIVITY_LOG 
WHERE empId = 0001 
LIMIT 10;

-- 6. SECONDARY INDEXES
-- =====================================================
-- Create secondary index on non-key column
CREATE INDEX ON EMPLOYEE (dept);

-- Query using secondary index
SELECT * FROM EMPLOYEE WHERE dept = 'Sales';

-- 7. MATERIALIZED VIEWS
-- =====================================================
-- Create materialized view for different query patterns
CREATE MATERIALIZED VIEW employees_by_dept AS
  SELECT empId, name, dept, salary
  FROM EMPLOYEE
  WHERE dept IS NOT NULL AND empId IS NOT NULL
  PRIMARY KEY (dept, empId);

-- Query materialized view
SELECT * FROM employees_by_dept WHERE dept = 'Engineering';

-- 8. UPDATE AND UPSERT OPERATIONS
-- =====================================================
-- Update specific fields (upsert behavior)
UPDATE EMPLOYEE 
SET salary = 52000 
WHERE empId = 0001;

-- Update with TTL (time to live)
UPDATE EMPLOYEE 
USING TTL 3600 
SET email = 'clark.new@company.com' 
WHERE empId = 0001;

-- 9. CONDITIONAL OPERATIONS
-- =====================================================
-- Insert if not exists
INSERT INTO EMPLOYEE(empId, name, dept, salary, hire_date)
VALUES (0005, 'Bob', 'Marketing', 45000, '2024-01-01')
IF NOT EXISTS;

-- Update with condition
UPDATE EMPLOYEE 
SET salary = 60000 
WHERE empId = 0002 
IF salary < 60000;

-- 10. BATCH OPERATIONS
-- =====================================================
-- Execute multiple operations atomically
BEGIN BATCH
  INSERT INTO EMPLOYEE(empId, name, dept, salary, hire_date)
  VALUES (0006, 'Lisa', 'HR', 48000, '2024-02-01');
  
  UPDATE EMPLOYEE 
  SET dept = 'Senior Sales' 
  WHERE empId = 0003;
  
  INSERT INTO EMPLOYEE_PROJECTS(empId, project_name, start_date, status)
  VALUES (0006, 'Onboarding Process', '2024-02-01', 'planning');
APPLY BATCH;

-- 11. DELETE OPERATIONS
-- =====================================================
-- Delete specific row
DELETE FROM EMPLOYEE WHERE empId = 0006;

-- Delete specific fields
DELETE email FROM EMPLOYEE WHERE empId = 0002;

-- Delete with conditions
DELETE FROM EMPLOYEE_PROJECTS 
WHERE empId = 0001 AND project_name = 'Website Redesign';

-- 12. ADVANCED QUERIES
-- =====================================================
-- Query with LIMIT
SELECT * FROM EMPLOYEE LIMIT 3;

-- Query with ORDER BY (only on clustering columns)
SELECT * FROM EMPLOYEE_PROJECTS 
WHERE empId = 0001 
ORDER BY project_name DESC;

-- Query with IN clause
SELECT * FROM EMPLOYEE WHERE empId IN (0001, 0003, 0004);

-- 13. AGGREGATION FUNCTIONS
-- =====================================================
-- Count records
SELECT COUNT(*) FROM EMPLOYEE;

-- Other aggregations (SUM, AVG, MIN, MAX)
SELECT dept, COUNT(*) as employee_count 
FROM employees_by_dept 
GROUP BY dept;

-- 14. USER-DEFINED TYPES (UDT)
-- =====================================================
-- Create custom type
CREATE TYPE address (
  street text,
  city text,
  state text,
  zip_code text
);

-- Table using UDT
CREATE TABLE EMPLOYEE_DETAILS (
  empId int PRIMARY KEY,
  name text,
  home_address address,
  work_address address
);

-- Insert with UDT
INSERT INTO EMPLOYEE_DETAILS(empId, name, home_address, work_address)
VALUES (0001, 'Clark', 
        {street: '123 Main St', city: 'Boston', state: 'MA', zip_code: '02101'},
        {street: '456 Corporate Blvd', city: 'Boston', state: 'MA', zip_code: '02102'});

-- 15. DESCRIBE OPERATIONS
-- =====================================================
-- Show table structure
DESCRIBE TABLE EMPLOYEE;

-- Show all tables in keyspace
DESCRIBE TABLES;

-- Show keyspace details
DESCRIBE KEYSPACE company;

-- =====================================================
-- PERFORMANCE TIPS AND BEST PRACTICES
-- =====================================================
-- 1. Always include partition key in WHERE clause
-- 2. Use clustering columns for range queries
-- 3. Avoid secondary indexes on high-cardinality columns
-- 4. Use materialized views for different query patterns
-- 5. Design tables based on query patterns, not normalization
-- 6. Use appropriate data types (avoid text for numeric IDs)
-- 7. Consider TTL for temporary data
-- 8. Use batches for related operations only
-- 9. Monitor partition sizes (keep under 100MB)
-- 10. Use LIMIT to prevent large result sets

-- =====================================================
-- CLEANUP
-- =====================================================
-- Drop materialized view
-- DROP MATERIALIZED VIEW employees_by_dept;

-- Drop tables
-- DROP TABLE EMPLOYEE_ACTIVITY_LOG;
-- DROP TABLE EMPLOYEE_PROJECTS;
-- DROP TABLE EMPLOYEE_SKILLS;
-- DROP TABLE EMPLOYEE_DETAILS;
-- DROP TABLE EMPLOYEE;

-- Drop UDT
-- DROP TYPE address;

-- Drop keyspace
-- DROP KEYSPACE company;