// MongoDB Retail Database - Clean Version for MyCompiler
// Copy this code section by section to avoid syntax errors

// Clear any existing data
db.customers.drop();
db.products.drop();
db.orders.drop();

print("Starting Retail Database Setup...");

// CUSTOMERS COLLECTION
print("1. Creating Customers...");

db.customers.insertMany([
  {
    customer_id: "CUST001",
    name: "Alice Johnson",
    email: "alice@email.com",
    age: 28,
    gender: "F",
    city: "New York",
    state: "NY",
    membership: "Gold",
    total_spent: 2450.75,
    preferences: ["electronics", "books", "clothing"]
  },
  {
    customer_id: "CUST002",
    name: "Bob Smith", 
    email: "bob@email.com",
    age: 35,
    gender: "M",
    city: "Los Angeles",
    state: "CA",
    membership: "Silver", 
    total_spent: 1875.50,
    preferences: ["sports", "electronics"]
  },
  {
    customer_id: "CUST003",
    name: "Charlie Brown",
    email: "charlie@email.com",
    age: 42,
    gender: "M", 
    city: "Chicago",
    state: "IL",
    membership: "Gold",
    total_spent: 3200.25,
    preferences: ["books", "music"]
  },
  {
    customer_id: "CUST004", 
    name: "Diana Wilson",
    email: "diana@email.com",
    age: 31,
    gender: "F",
    city: "Miami",
    state: "FL",
    membership: "Bronze",
    total_spent: 980.40,
    preferences: ["fashion", "beauty"]
  },
  {
    customer_id: "CUST005",
    name: "Emma Davis",
    email: "emma@email.com",
    age: 26, 
    gender: "F",
    city: "Seattle",
    state: "WA",
    membership: "Silver",
    total_spent: 1650.80,
    preferences: ["books", "coffee"]
  }
]);

print("Customers inserted successfully!");

// PRODUCTS COLLECTION
print("2. Creating Products...");

db.products.insertMany([
  {
    product_id: "PROD001",
    name: "iPhone 15 Pro",
    category: "Electronics",
    brand: "Apple",
    price: 999.99,
    stock: 45,
    rating: 4.8
  },
  {
    product_id: "PROD002", 
    name: "MacBook Air M3",
    category: "Electronics",
    brand: "Apple", 
    price: 1299.99,
    stock: 25,
    rating: 4.9
  },
  {
    product_id: "PROD003",
    name: "Samsung 55 QLED TV",
    category: "Electronics",
    brand: "Samsung",
    price: 899.99,
    stock: 15,
    rating: 4.6
  },
  {
    product_id: "PROD004",
    name: "Nike Air Jordan 1", 
    category: "Fashion",
    brand: "Nike",
    price: 170.00,
    stock: 120,
    rating: 4.7
  },
  {
    product_id: "PROD005",
    name: "Dyson V15 Vacuum",
    category: "Home",
    brand: "Dyson",
    price: 549.99,
    stock: 30,
    rating: 4.5
  },
  {
    product_id: "PROD006",
    name: "The Great Gatsby",
    category: "Books",
    brand: "Scribner", 
    price: 15.99,
    stock: 200,
    rating: 4.2
  }
]);

print("Products inserted successfully!");

// ORDERS COLLECTION  
print("3. Creating Orders...");

db.orders.insertMany([
  {
    order_id: "ORD001",
    customer_id: "CUST001",
    status: "delivered",
    items: [
      {product_id: "PROD001", quantity: 1, price: 999.99},
      {product_id: "PROD006", quantity: 2, price: 15.99}
    ],
    total_amount: 1031.97,
    order_date: "2024-02-15"
  },
  {
    order_id: "ORD002",
    customer_id: "CUST002", 
    status: "shipped",
    items: [
      {product_id: "PROD004", quantity: 2, price: 170.00}
    ],
    total_amount: 340.00,
    order_date: "2024-02-18"
  },
  {
    order_id: "ORD003",
    customer_id: "CUST003",
    status: "processing", 
    items: [
      {product_id: "PROD002", quantity: 1, price: 1299.99},
      {product_id: "PROD005", quantity: 1, price: 549.99}
    ],
    total_amount: 1849.98,
    order_date: "2024-02-20"
  },
  {
    order_id: "ORD004",
    customer_id: "CUST005",
    status: "delivered",
    items: [
      {product_id: "PROD006", quantity: 3, price: 15.99}
    ],
    total_amount: 47.97,
    order_date: "2024-02-25"
  }
]);

print("Orders inserted successfully!");

// BASIC QUERIES
print("4. Running Basic Queries...");
print("============================");

print("All Customers:");
db.customers.find();

print("Female Customers:");  
db.customers.find({gender: "F"});

print("Gold Members:");
db.customers.find({membership: "Gold"});

print("Electronics Products:");
db.products.find({category: "Electronics"});

print("Products Under $100:");
db.products.find({price: {$lt: 100}});

print("Completed Orders:");
db.orders.find({status: "delivered"});

// ADVANCED QUERIES
print("5. Running Advanced Queries...");
print("===============================");

print("Customers aged 25-35:");
db.customers.find({age: {$gte: 25, $lte: 35}});

print("Customers interested in books:");
db.customers.find({preferences: "books"});

print("Electronics over $500:");
db.products.find({
  category: "Electronics",
  price: {$gt: 500}
});

print("Customers from NY or CA:");
db.customers.find({
  $or: [
    {state: "NY"},
    {state: "CA"}
  ]
});

// AGGREGATION QUERIES
print("6. Running Aggregation Queries...");
print("==================================");

print("Customers by Membership:");
db.customers.aggregate([
  {$group: {
    _id: "$membership", 
    count: {$sum: 1},
    avg_spent: {$avg: "$total_spent"}
  }}
]);

print("Top 3 Spenders:");
db.customers.aggregate([
  {$sort: {total_spent: -1}},
  {$limit: 3},
  {$project: {name: 1, total_spent: 1}}
]);

print("Products by Category:");
db.products.aggregate([
  {$group: {
    _id: "$category",
    count: {$sum: 1}, 
    avg_price: {$avg: "$price"}
  }}
]);

print("Order Status Summary:");
db.orders.aggregate([
  {$group: {
    _id: "$status",
    count: {$sum: 1},
    total_value: {$sum: "$total_amount"}
  }}
]);

// UPDATE EXAMPLES
print("7. Update Examples...");
print("=====================");

print("Updating customer membership:");
db.customers.updateOne(
  {customer_id: "CUST004"}, 
  {$set: {membership: "Silver"}}
);

print("Adding preference to customer:");
db.customers.updateOne(
  {customer_id: "CUST001"},
  {$push: {preferences: "home"}}
);

print("Updating product stock:");
db.products.updateOne(
  {product_id: "PROD001"},
  {$inc: {stock: -5}}
);

// COUNT DOCUMENTS
print("8. Document Counts...");
print("=====================");

print("Total Customers:", db.customers.countDocuments());
print("Total Products:", db.products.countDocuments()); 
print("Total Orders:", db.orders.countDocuments());

print("Female Customers:", db.customers.countDocuments({gender: "F"}));
print("Gold Members:", db.customers.countDocuments({membership: "Gold"}));
print("Electronics Products:", db.products.countDocuments({category: "Electronics"}));

// FIND WITH PROJECTIONS
print("9. Projection Examples...");
print("=========================");

print("Customer Names and Cities:");
db.customers.find({}, {name: 1, city: 1, _id: 0});

print("Product Names and Prices:");
db.products.find({}, {name: 1, price: 1, _id: 0});

print("Order IDs and Totals:");
db.orders.find({}, {order_id: 1, total_amount: 1, _id: 0});

// SORTING EXAMPLES
print("10. Sorting Examples...");
print("=======================");

print("Customers by Age (Descending):");
db.customers.find({}, {name: 1, age: 1, _id: 0}).sort({age: -1});

print("Products by Price (Ascending):");
db.products.find({}, {name: 1, price: 1, _id: 0}).sort({price: 1});

print("Orders by Amount (Descending):");
db.orders.find({}, {order_id: 1, total_amount: 1, _id: 0}).sort({total_amount: -1});

// FINAL STATISTICS
print("11. Final Statistics...");
print("=======================");

print("Database Summary:");
db.customers.aggregate([
  {$group: {
    _id: null,
    total_customers: {$sum: 1},
    total_spent_all: {$sum: "$total_spent"},
    avg_customer_value: {$avg: "$total_spent"}
  }}
]);

print("Revenue by Status:");
db.orders.aggregate([
  {$group: {
    _id: "$status",
    order_count: {$sum: 1},
    total_revenue: {$sum: "$total_amount"}
  }},
  {$sort: {total_revenue: -1}}
]);

print("Retail Database Setup Complete!");
print("================================");

// Additional query examples you can try:
print("Try these additional queries:");
print("db.customers.find({total_spent: {$gt: 2000}});");
print("db.products.find({stock: {$lt: 50}});"); 
print("db.orders.find({total_amount: {$gte: 1000}});");
print("db.customers.distinct('state');");
print("db.products.distinct('category');");